Oncology
Sleepy068

Installing:
1. Extract the zip file (to where ever if need be)
2. Delete any previous versions of the mod at the steam path below, do NOT override the files.
3. Copy the file 'Mod_Oncology' to your Project Hospital installation addon's folder (see below).

Steam Path: C:\Program Files (x86)\Steam\steamapps\common\Project Hospital\ProjectHospital_Data\StreamingAssets\Addons\*put mod here*

3. Done, launch the game and enjoy.

Troubleshooting:
- Mod didn't load?
Make sure the mod's path file is as follows:
C:\Program Files (x86)\Steam\steamapps\common\Project Hospital\ProjectHospital_Data\StreamingAssets\Addons\Mod_Oncology
In the mod file should be Database, heaps of PNGs, steamworkshop ID & Preview.png

- Bugs or issues?
Please report any issues here: https://github.com/sleepy068/ProjectHospital_Oncology/issues
